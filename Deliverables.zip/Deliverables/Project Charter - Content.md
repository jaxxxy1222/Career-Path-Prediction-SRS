# Project Charter — Career Path Prediction & Guidance System

## Project Title
Career Path Prediction & Guidance System

## Project Purpose / Objective
To develop a standalone web application that uses machine learning and deep learning models to predict suitable career paths for students based on their academic profile, technical skills, and areas of interest. The system provides personalized career guidance and curated course recommendations to help students make informed decisions about their professional development.

## Project Scope

### In Scope
- Loading and preprocessing student datasets (CSV/Excel)
- Exploratory Data Analysis (EDA) with automated visualization generation
- Training classical ML models: Random Forest, SVM, KNN, Logistic Regression
- Training a deep learning model (TensorFlow/Keras neural network)
- Automatic model evaluation and best-model selection by F1-score
- Model serialization and deserialization using Joblib
- Streamlit-based interactive web UI for student input and career prediction
- Curated course recommendations for 10 career labels
- Input validation with descriptive error messages
- Offline training pipeline script (train_pipeline.py)

### Out of Scope
- Real-time dataset updates or live data ingestion
- User authentication or user account management
- Mobile application development
- Cloud deployment or CI/CD pipeline
- Multi-language support

## Project Deliverables
1. Python source code (src/ modules)
2. Streamlit web application (app.py)
3. Offline training pipeline (train_pipeline.py)
4. Trained model artifacts (artifacts/)
5. EDA visualizations (eda_output/)
6. Unit test suite (tests/)
7. Requirements file (requirements.txt)
8. Project documentation (this deliverables folder)

## Stakeholders
| Role | Name | Responsibility |
|------|------|----------------|
| Project Sponsor | — | Approves scope and resources |
| Project Manager | — | Oversees delivery and schedule |
| Developer/Intern | — | Implements and maintains the system |
| Primary End User | Student | Submits profile and receives career guidance |

## Technology Stack
| Component | Technology |
|-----------|------------|
| Language | Python 3.9+ |
| Web Framework | Streamlit 1.35+ |
| ML Library | scikit-learn 1.5.0 |
| Deep Learning | TensorFlow 2.16.1 / Keras |
| Data Processing | Pandas 2.2.2, NumPy 1.26.4 |
| Visualization | Matplotlib 3.9.0, Seaborn 0.13.2 |
| Serialization | Joblib 1.4.2 |
| Testing | pytest 8.2.2, hypothesis 6.103.1 |

## Project Timeline (High Level)
| Phase | Description | Duration |
|-------|-------------|----------|
| Phase 1 | Requirements & Design | Week 1 |
| Phase 2 | Data Layer (loader + preprocessor) | Week 2 |
| Phase 3 | Model Training & Evaluation | Week 3 |
| Phase 4 | Prediction & Recommendation | Week 4 |
| Phase 5 | Streamlit UI & Integration | Week 5 |
| Phase 6 | Testing & Final Integration | Week 6 |

## Success Criteria
- All 4 classical ML models train without errors
- Best model selected by weighted F1-score and saved as artifact
- Streamlit UI serves predictions within 3 seconds
- Input validation catches empty/invalid fields before prediction
- At least 3 course recommendations returned per career label
- 59+ automated tests passing

## Approved By
| Role | Signature | Date |
|------|-----------|------|
| Project Sponsor | | |
| Project Manager | | |
