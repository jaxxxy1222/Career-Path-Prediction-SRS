# Project Schedule — Career Path Prediction & Guidance System

## Summary
Total Duration: 6 Weeks
Methodology: Incremental / Layered Development

---

## Work Breakdown by Phase

### Phase 1 — Project Scaffold & Requirements (Week 1)
| Task ID | Task | Status | Owner |
|---------|------|--------|-------|
| 1.1 | Create directory structure (src/, tests/, artifacts/, eda_output/, data/) | ✅ Complete | Dev |
| 1.2 | Define shared data models (StudentInput, EvaluationResult, Course, PredictionResult) | ✅ Complete | Dev |
| 1.3 | Define custom exception (PredictorError) | ✅ Complete | Dev |
| 1.4 | Create test configuration (conftest.py with Hypothesis profile) | ✅ Complete | Dev |
| 1.5 | Pin all dependencies in requirements.txt | ✅ Complete | Dev |

### Phase 2 — Data Layer (Week 2)
| Task ID | Task | Status | Owner |
|---------|------|--------|-------|
| 2.1 | Implement data_loader.py (load_dataset, get_dataset_info) | ✅ Complete | Dev |
| 2.2 | Implement preprocessor.py (Preprocessor class + stratified_split) | ✅ Complete | Dev |
| 2.3 | Write unit tests for data_loader.py (20 tests) | ✅ Complete | Dev |
| 2.4 | Checkpoint: all data layer tests pass | ✅ Complete | Dev |

### Phase 3 — EDA Module (Week 2–3)
| Task ID | Task | Status | Owner |
|---------|------|--------|-------|
| 3.1 | Implement eda_module.py (run_eda, plot_distributions, plot_correlation_heatmap, plot_class_balance) | ✅ Complete | Dev |

### Phase 4 — Model Training & Evaluation (Week 3–4)
| Task ID | Task | Status | Owner |
|---------|------|--------|-------|
| 4.1 | Implement trainer.py (train_classical_models, train_deep_learning_model, evaluate_model, evaluate_all) | ✅ Complete | Dev |
| 4.2 | Write unit tests for Trainer (16 tests, 5 skipped pending TF install) | ✅ Complete | Dev |
| 4.3 | Implement selector.py (select_best_model, save_artifacts) | ✅ Complete | Dev |
| 4.4 | Checkpoint: training pipeline tests pass | ✅ Complete | Dev |

### Phase 5 — Prediction, Recommendation & Validation (Week 4–5)
| Task ID | Task | Status | Owner |
|---------|------|--------|-------|
| 5.1 | Implement predictor.py (Predictor class) | ✅ Complete | Dev |
| 5.2 | Implement recommender.py (COURSE_MAP + get_recommendations for 10 careers) | ✅ Complete | Dev |
| 5.3 | Implement validator.py (validate_student_input) | ✅ Complete | Dev |
| 5.4 | Write unit tests for validator (28 tests) | ✅ Complete | Dev |

### Phase 6 — UI & Integration (Week 5–6)
| Task ID | Task | Status | Owner |
|---------|------|--------|-------|
| 6.1 | Implement app.py (Streamlit UI with form, validation, prediction, recommendations) | ✅ Complete | Dev |
| 6.2 | Implement train_pipeline.py (end-to-end offline training CLI script) | ✅ Complete | Dev |
| 6.3 | Final integration checkpoint: 59 tests passing, pipeline runs end-to-end | ✅ Complete | Dev |

---

## Milestone Summary
| Milestone | Target Date | Status |
|-----------|-------------|--------|
| M1: Project scaffold complete | Week 1 | ✅ Done |
| M2: Data layer complete | Week 2 | ✅ Done |
| M3: Training pipeline complete | Week 4 | ✅ Done |
| M4: Prediction & UI complete | Week 5 | ✅ Done |
| M5: Full integration verified | Week 6 | ✅ Done |

---

## Test Results Summary
| Test File | Tests | Passed | Skipped | Failed |
|-----------|-------|--------|---------|--------|
| test_data_loader.py | 20 | 20 | 0 | 0 |
| test_trainer.py | 16 | 11 | 5* | 0 |
| test_validator.py | 28 | 28 | 0 | 0 |
| **Total** | **64** | **59** | **5** | **0** |

*5 deep learning tests skipped — require TensorFlow installation
