# Work Breakdown Structure (WBS)
## Career Path Prediction & Guidance System

---

## Level 1: Project Phases

```
Career Path Prediction & Guidance System
├── 1. Project Management
├── 2. Requirements & Design
├── 3. Data Layer
├── 4. Model Training Pipeline
├── 5. Prediction & Recommendation
├── 6. User Interface
├── 7. Testing & Quality Assurance
└── 8. Documentation & Deliverables
```

---

## Level 2–3: Detailed Breakdown

### 1. Project Management
- 1.1 Define project scope and objectives
- 1.2 Identify stakeholders
- 1.3 Create project charter
- 1.4 Develop project schedule
- 1.5 Maintain RAID log
- 1.6 Conduct lessons learnt review

### 2. Requirements & Design
- 2.1 Conduct requirement elicitation (questionnaire)
- 2.2 Write Software Requirements Specification (SRS)
- 2.3 Define system architecture (three-tier: data / model / UI)
- 2.4 Define data models (StudentInput, EvaluationResult, Course, PredictionResult)
- 2.5 Define component interfaces (DataLoader, Preprocessor, Trainer, Selector, Predictor, Recommender, Validator)
- 2.6 Define correctness properties (12 properties for property-based testing)
- 2.7 Write implementation task list

### 3. Data Layer
- 3.1 Implement DataLoader
  - 3.1.1 CSV loading (pd.read_csv)
  - 3.1.2 Excel loading (pd.read_excel)
  - 3.1.3 Error handling (FileNotFoundError, ValueError)
  - 3.1.4 Dataset info reporting
- 3.2 Implement Preprocessor
  - 3.2.1 Numeric imputation (median)
  - 3.2.2 Categorical imputation (mode)
  - 3.2.3 OneHotEncoder for categorical features
  - 3.2.4 MinMaxScaler for numeric features
  - 3.2.5 fit / transform / fit_transform methods
  - 3.2.6 Joblib save / load serialization
  - 3.2.7 Class size warning (< 10 samples)
  - 3.2.8 stratified_split utility (80/20)
- 3.3 Implement EDA Module
  - 3.3.1 Distribution plots (one per numeric column)
  - 3.3.2 Correlation heatmap
  - 3.3.3 Class balance bar chart
  - 3.3.4 Auto-create output directory

### 4. Model Training Pipeline
- 4.1 Implement Trainer — Classical Models
  - 4.1.1 Random Forest Classifier
  - 4.1.2 SVM (probability=True)
  - 4.1.3 K-Nearest Neighbors
  - 4.1.4 Logistic Regression
  - 4.1.5 Per-model exception handling (log + skip)
- 4.2 Implement Trainer — Deep Learning
  - 4.2.1 Keras Sequential architecture (Input → 256 Dense → 128 Dense → softmax)
  - 4.2.2 BatchNormalization + Dropout(0.3) layers
  - 4.2.3 EarlyStopping (patience=5, restore_best_weights=True)
  - 4.2.4 Graceful skip if TensorFlow missing
- 4.3 Implement Model Evaluation
  - 4.3.1 Accuracy, Precision, Recall, F1 (weighted)
  - 4.3.2 Confusion matrix generation
  - 4.3.3 evaluate_all summary DataFrame
- 4.4 Implement Selector
  - 4.4.1 select_best_model (idxmax on F1-score)
  - 4.4.2 save_artifacts (model, preprocessor, label_encoder)
- 4.5 Implement Training Pipeline Script
  - 4.5.1 argparse CLI (--data, --target)
  - 4.5.2 Full orchestration (load → EDA → split → preprocess → train → evaluate → select → save)
  - 4.5.3 Graceful error exit (FileNotFoundError, ValueError)

### 5. Prediction & Recommendation
- 5.1 Implement Predictor
  - 5.1.1 Load artifacts at init (FileNotFoundError if missing)
  - 5.1.2 predict() → (career_label, confidence_score)
  - 5.1.3 PredictorError wrapping
- 5.2 Implement Recommender
  - 5.2.1 Static COURSE_MAP (10 career labels × ≥3 courses each)
  - 5.2.2 DEFAULT_COURSES fallback (≥3 generic courses)
  - 5.2.3 get_recommendations() function
- 5.3 Implement Input Validator
  - 5.3.1 Required field validation (gpa, technical_skills, interests)
  - 5.3.2 GPA type validation (numeric coercion)
  - 5.3.3 GPA range validation [0.0, 100.0]
  - 5.3.4 Empty list / blank string validation

### 6. User Interface
- 6.1 Implement Streamlit App (app.py)
  - 6.1.1 @st.cache_resource Predictor loading
  - 6.1.2 FileNotFoundError display at startup
  - 6.1.3 Student input form (GPA, skills, interests, soft skills, extracurricular)
  - 6.1.4 Per-field validation error display
  - 6.1.5 Career label display (st.success)
  - 6.1.6 Confidence score display (st.metric)
  - 6.1.7 Course recommendations display (st.markdown links)
  - 6.1.8 PredictorError error display

### 7. Testing & Quality Assurance
- 7.1 Unit Tests — DataLoader (20 tests)
- 7.2 Unit Tests — Trainer (16 tests, 5 require TF)
- 7.3 Unit Tests — Validator (28 tests)
- 7.4 Integration Test — train_pipeline.py end-to-end run
- 7.5 Manual Test — Streamlit app demo verification

### 8. Documentation & Deliverables
- 8.1 Project Charter
- 8.2 Project Schedule
- 8.3 RAID Log
- 8.4 Lessons Learnt Log
- 8.5 Requirement Elicitation Questionnaire
- 8.6 Software Requirements Specification (SRS)
- 8.7 Work Breakdown Structure (WBS)
- 8.8 Project Report
- 8.9 Code docstrings (all public functions and classes)

---

## WBS Summary Table

| WBS ID | Deliverable | Status |
|--------|-------------|--------|
| 3.1 | src/data_loader.py | ✅ Complete |
| 3.2 | src/preprocessor.py | ✅ Complete |
| 3.3 | src/eda_module.py | ✅ Complete |
| 4.1–4.3 | src/trainer.py | ✅ Complete |
| 4.4 | src/selector.py | ✅ Complete |
| 4.5 | train_pipeline.py | ✅ Complete |
| 5.1 | src/predictor.py | ✅ Complete |
| 5.2 | src/recommender.py | ✅ Complete |
| 5.3 | src/validator.py | ✅ Complete |
| 6.1 | app.py | ✅ Complete |
| 7.1–7.5 | tests/ | ✅ 59/64 passing |
| 8.1–8.9 | src/Deliverables/ | ✅ Complete |
