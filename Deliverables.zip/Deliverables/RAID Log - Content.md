# RAID Log — Career Path Prediction & Guidance System

RAID = Risks, Assumptions, Issues, Dependencies

---

## RISKS

| ID | Risk Description | Probability | Impact | Mitigation | Status |
|----|-----------------|-------------|--------|------------|--------|
| R1 | TensorFlow not available in target environment | Medium | Medium | Deep learning model training wrapped in try/except; pipeline continues with classical models only | Mitigated |
| R2 | NumPy/scikit-learn version conflicts across environments | High | High | Pin exact versions in requirements.txt; recommend using virtual environment | Mitigated |
| R3 | Dataset column names don't match expected model input columns | Medium | High | Preprocessor uses detected column names at fit time; form sends matching column names | Mitigated |
| R4 | scikit-learn version mismatch when loading artifacts | Medium | High | Retrain pipeline on same environment; artifacts and code must use same scikit-learn version | Active |
| R5 | Streamlit breaking changes in newer versions | Low | Medium | Streamlit version pinned in requirements.txt | Mitigated |
| R6 | Insufficient training data leading to poor model accuracy | Medium | High | Dataset should have ≥10 samples per career class; warning emitted if not | Monitoring |
| R7 | Model artifacts corrupted or missing at app startup | Low | High | FileNotFoundError caught at startup; user-friendly error shown with instructions | Mitigated |

---

## ASSUMPTIONS

| ID | Assumption |
|----|------------|
| A1 | Python 3.9+ is installed on the target machine |
| A2 | All dependencies in requirements.txt can be installed via pip |
| A3 | The training dataset has a clearly identified target column (career label) |
| A4 | The training dataset contains at least 50 samples total and at least 10 per class |
| A5 | The app is run in the same directory as src/, artifacts/, and train_pipeline.py |
| A6 | train_pipeline.py is run before app.py (artifacts must exist before the UI starts) |
| A7 | Users have a local browser available for the Streamlit UI |
| A8 | No internet connection is required at inference time (courses are static) |

---

## ISSUES

| ID | Issue Description | Raised Date | Priority | Resolution | Status |
|----|------------------|-------------|----------|------------|--------|
| I1 | numpy.long removed in NumPy 1.24+ — broke scikit-learn 1.9.0 | During setup | High | Downgraded to scikit-learn 1.5.0 / upgraded NumPy | Resolved |
| I2 | Streamlit 1.35.0 incompatible with NumPy 2.x | During setup | High | Upgraded to Streamlit 1.58.0 which supports NumPy 1.26.4 | Resolved |
| I3 | Artifacts trained with scikit-learn 1.9.0, loaded with 1.5.0 — InconsistentVersionWarning | During demo | Medium | Retrained pipeline with scikit-learn 1.5.0 | Resolved |
| I4 | Form raw_input dict contained columns not in the trained preprocessor | During demo | High | Filtered raw_input to only send gpa, technical_skills, interests to predictor | Resolved |
| I5 | 5 deep learning tests skipped when TensorFlow not installed | Testing | Low | Tests use pytest.importorskip — will run when TF is installed | Open/Acceptable |

---

## DEPENDENCIES

| ID | Dependency | Type | Impact if Missing |
|----|-----------|------|-------------------|
| D1 | Python 3.9+ | External | System cannot run |
| D2 | scikit-learn 1.5.0 | External | Model training and preprocessing unavailable |
| D3 | Streamlit 1.35+ | External | Web UI unavailable |
| D4 | pandas 2.2.2 | External | Data loading and preprocessing unavailable |
| D5 | numpy 1.26.4 | External | All numerical operations unavailable |
| D6 | TensorFlow 2.16.1 | External (optional) | Deep learning model skipped; classical models still work |
| D7 | joblib 1.4.2 | External | Model serialization unavailable |
| D8 | matplotlib + seaborn | External | EDA plots unavailable |
| D9 | train_pipeline.py must run before app.py | Internal | Predictor raises FileNotFoundError at startup |
| D10 | artifacts/ directory with model.joblib, preprocessor.joblib, label_encoder.joblib | Internal | App cannot serve predictions |
