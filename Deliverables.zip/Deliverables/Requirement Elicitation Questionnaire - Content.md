# Requirement Elicitation Questionnaire — Career Path Prediction & Guidance System

This questionnaire was used to gather requirements from stakeholders before development began.

---

## Section 1: System Purpose & Users

**Q1. Who are the primary users of this system?**  
A: Students who want personalized career path recommendations based on their academic profile.

**Q2. Who are the secondary users?**  
A: Developers and interns who maintain, retrain, and update the ML models.

**Q3. What problem does this system solve for students?**  
A: Students often don't know which career path suits their skills and academic performance. This system provides data-driven predictions with actionable course recommendations.

**Q4. What is the expected frequency of use?**  
A: On-demand — students use it when exploring career options. Training pipeline run periodically by developers when new data is available.

---

## Section 2: Data Requirements

**Q5. What data will the system use for training?**  
A: A labeled CSV or Excel dataset with student records containing academic scores, skills, interests, and a career label column.

**Q6. What file formats must be supported?**  
A: CSV (.csv) and Excel (.xlsx, .xls).

**Q7. What should happen if the file is missing or in the wrong format?**  
A: The system should raise a descriptive error identifying the problem (missing path or unsupported format).

**Q8. What should happen with missing values in the dataset?**  
A: Numeric missing values → impute with column median. Categorical missing values → impute with column mode.

**Q9. How should the dataset be split for training and testing?**  
A: 80% training, 20% test, using stratified sampling to preserve class distribution.

---

## Section 3: Model Requirements

**Q10. Which machine learning models should be trained?**  
A: At minimum: Random Forest, Support Vector Machine (SVM), K-Nearest Neighbors (KNN), Logistic Regression.

**Q11. Should a deep learning model also be included?**  
A: Yes — a TensorFlow/Keras neural network with at least 2 hidden layers and early stopping.

**Q12. How should the best model be selected?**  
A: By highest weighted F1-score across all trained models.

**Q13. Should the model be retrained every time a student submits a prediction?**  
A: No. The model is trained offline and saved. The web app loads the saved model at startup.

**Q14. What metrics should be reported for each model?**  
A: Accuracy, weighted Precision, weighted Recall, weighted F1-score, and Confusion Matrix.

---

## Section 4: Prediction & Recommendations

**Q15. What should the system output when a student submits their profile?**  
A: A predicted career label and a confidence score (0–100%).

**Q16. How many career labels should the system support?**  
A: At minimum 10: Data Scientist, Software Engineer, Machine Learning Engineer, Data Analyst, Web Developer, Cybersecurity Analyst, Business Analyst, UX Designer, Network Engineer, Database Administrator.

**Q17. Should the system recommend courses?**  
A: Yes — at least 3 courses per predicted career, with title, provider name, and a clickable URL.

**Q18. What if the predicted career has no courses mapped?**  
A: Return a default set of at least 3 general career development courses.

**Q19. Should predictions be deterministic (same input → same output)?**  
A: Yes — the same input must always produce the same career label and confidence score.

---

## Section 5: User Interface

**Q20. What type of interface is required?**  
A: A web-based form accessible from a browser. Streamlit is the chosen framework.

**Q21. What input fields should the form have?**  
A: GPA/Overall Score, Technical Skills, Areas of Interest, Soft Skills (optional), Extracurricular Activities (optional).

**Q22. What should happen if a required field is left empty?**  
A: Show a field-level validation error message. Do not call the prediction model.

**Q23. What should happen if the model artifacts are missing at startup?**  
A: Display a user-friendly error message telling the user to run the training pipeline first.

**Q24. What should happen if an unexpected error occurs during prediction?**  
A: Display a generic "An unexpected error occurred. Please try again." message without showing stack traces.

---

## Section 6: Non-Functional Requirements

**Q25. How fast should predictions be?**  
A: Career label returned within 3 seconds of form submission.

**Q26. What Python version should be supported?**  
A: Python 3.9 and above.

**Q27. Should the system work offline?**  
A: Yes — both training and inference run locally with no internet connection required.

**Q28. How should the codebase be organized?**  
A: Separate modules for data processing, training, prediction, recommendation, and UI. Each module must have docstrings on all public functions.

**Q29. Should there be automated tests?**  
A: Yes — unit tests with pytest and property-based tests with hypothesis.

**Q30. How should dependencies be managed?**  
A: A requirements.txt file with all dependencies pinned to exact versions.
