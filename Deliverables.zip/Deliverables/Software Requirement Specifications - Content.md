# Software Requirements Specification (SRS)
## Career Path Prediction & Guidance System

**Version:** 1.0  
**Status:** Final  

---

## 1. Introduction

### 1.1 Purpose
This document specifies the functional and non-functional requirements for the Career Path Prediction & Guidance System — a standalone Python web application that predicts career paths for students using machine learning.

### 1.2 Scope
The system accepts a student's academic profile (GPA, skills, interests) through a Streamlit web form, runs it through a pre-trained ML model, and returns a career prediction with a confidence score and curated course recommendations.

### 1.3 Intended Audience
- Developers implementing the system
- Students using the system
- Instructors/supervisors evaluating the project

### 1.4 Definitions
| Term | Definition |
|------|-----------|
| Predictor | The trained model used for inference |
| Preprocessor | The data transformation pipeline |
| Trainer | Component that trains and evaluates all models |
| Selector | Component that picks the best model by F1-score |
| Recommender | Component that maps career labels to course lists |
| Career_Label | A string class representing a career (e.g., "Data Scientist") |
| Confidence_Score | Max class probability from the Predictor (0.0–1.0) |
| Model_Artifact | Serialized model file produced by Joblib |

---

## 2. System Overview

The system has two operational modes:

**Offline Training Mode** (`python train_pipeline.py --data <path>`)  
Loads dataset → EDA → Preprocessing → Train models → Evaluate → Select best → Save artifacts

**Online Inference Mode** (`streamlit run app.py`)  
Load artifacts → Accept student input → Validate → Preprocess → Predict → Recommend courses

---

## 3. Functional Requirements

### FR-01: Data Loading
- FR-01.1: Load CSV files via pandas.read_csv without data loss
- FR-01.2: Load Excel (.xlsx/.xls) files via pandas.read_excel without data loss
- FR-01.3: Raise FileNotFoundError with descriptive message for missing files
- FR-01.4: Raise ValueError with descriptive message for unsupported file formats
- FR-01.5: Report row count, column count, and column names after loading

### FR-02: Data Preprocessing
- FR-02.1: Impute missing numeric values using column median
- FR-02.2: Impute missing categorical values using column mode (most frequent)
- FR-02.3: Encode categorical features using OneHotEncoder
- FR-02.4: Normalize numeric features to [0, 1] using MinMaxScaler
- FR-02.5: Fit all transformers exclusively on training data; apply to test data without refitting
- FR-02.6: Split dataset 80/20 using stratified sampling on the target column
- FR-02.7: Emit UserWarning for any class with fewer than 10 samples

### FR-03: Exploratory Data Analysis
- FR-03.1: Generate histogram + KDE distribution plot for each numeric feature
- FR-03.2: Generate Pearson correlation heatmap for all numeric features
- FR-03.3: Generate bar chart of sample counts per career label
- FR-03.4: Save all plots as PNG files to a configurable output directory
- FR-03.5: Create the output directory automatically if it does not exist

### FR-04: Classical ML Training
- FR-04.1: Train Random Forest, SVM (probability=True), KNN, Logistic Regression
- FR-04.2: Use preprocessed training data for all model training
- FR-04.3: Log elapsed training time for each model
- FR-04.4: Continue training remaining models if one raises an exception

### FR-05: Deep Learning Training
- FR-05.1: Train a Keras Sequential network with ≥2 hidden layers
- FR-05.2: Set input layer size = number of preprocessed features
- FR-05.3: Set output layer size = number of career labels, with softmax activation
- FR-05.4: Apply EarlyStopping (patience=5, monitor=val_loss, restore_best_weights=True)
- FR-05.5: Gracefully skip DL training if TensorFlow is not installed

### FR-06: Model Evaluation
- FR-06.1: Compute accuracy, weighted precision, weighted recall, weighted F1 on test set
- FR-06.2: Generate and store confusion matrix per model
- FR-06.3: Evaluate all models (classical + DL) on the same test set
- FR-06.4: Produce a summary DataFrame comparing all models

### FR-07: Model Selection & Serialization
- FR-07.1: Select model with highest weighted F1-score as best model
- FR-07.2: Serialize best model to artifacts/model.joblib using Joblib
- FR-07.3: Serialize fitted Preprocessor to artifacts/preprocessor.joblib
- FR-07.4: Serialize fitted LabelEncoder to artifacts/label_encoder.joblib
- FR-07.5: Load all artifacts at app startup without retraining
- FR-07.6: Raise FileNotFoundError("Run training pipeline first.") if any artifact is missing

### FR-08: Student Input Form
- FR-08.1: Display labeled fields for GPA, Technical Skills, Interests, Soft Skills, Extracurricular
- FR-08.2: Include placeholder text and help text for each field
- FR-08.3: Show field-level validation errors on empty required fields without calling predictor
- FR-08.4: Show descriptive error for non-numeric or out-of-range GPA
- FR-08.5: Include a "Predict Career" submit button

### FR-09: Career Prediction
- FR-09.1: Apply preprocessor to input and return career label within 3 seconds
- FR-09.2: Display predicted career label prominently in the UI
- FR-09.3: Display confidence score as a percentage
- FR-09.4: Show user-friendly error (no stack traces) if prediction fails
- FR-09.5: Return identical career label for identical inputs (deterministic)

### FR-10: Course Recommendations
- FR-10.1: Return ≥3 courses per predicted career label
- FR-10.2: Display each course with title, provider, and clickable URL
- FR-10.3: Return default courses if career label has no mapping
- FR-10.4: Cover all 10 required career labels in the static course map

### FR-11: Error Handling
- FR-11.1: Highlight empty required fields with descriptive error messages
- FR-11.2: Show valid range in error for out-of-range numeric input
- FR-11.3: Log errors internally; display generic message to user
- FR-11.4: Never crash on Predictor or Recommender exceptions

### FR-12: Modularity & Portability
- FR-12.1: Separate modules for data processing, training, prediction, recommendation, UI
- FR-12.2: Provide requirements.txt with exact pinned versions
- FR-12.3: Include docstrings on all public functions and classes
- FR-12.4: Run on Python 3.9+ with dependencies from requirements.txt

---

## 4. Non-Functional Requirements

| ID | Requirement | Metric |
|----|-------------|--------|
| NFR-01 | Prediction response time | < 3 seconds |
| NFR-02 | Python version compatibility | Python 3.9+ |
| NFR-03 | Offline operation | No internet required at inference time |
| NFR-04 | Test coverage | ≥59 automated tests passing |
| NFR-05 | Code documentation | All public functions have docstrings |
| NFR-06 | Reproducibility | Same input always produces same output |

---

## 5. System Architecture

```
Offline Training Pipeline:
  Dataset → DataLoader → Preprocessor → Trainer → Evaluator → Selector → Artifacts

Online Inference:
  Student Form → Validator → Preprocessor (transform) → Predictor → Recommender → UI
```

### Module Responsibilities
| Module | File | Responsibility |
|--------|------|----------------|
| DataLoader | src/data_loader.py | Load CSV/Excel datasets |
| Preprocessor | src/preprocessor.py | Impute, encode, scale features |
| EDA_Module | src/eda_module.py | Generate and save visualizations |
| Trainer | src/trainer.py | Train and evaluate all models |
| Selector | src/selector.py | Select best model, save artifacts |
| Predictor | src/predictor.py | Load artifacts, serve predictions |
| Recommender | src/recommender.py | Return course recommendations |
| Validator | src/validator.py | Validate student form input |
| Models | src/models.py | Shared dataclasses |
| Exceptions | src/exceptions.py | Custom exception classes |
| UI | app.py | Streamlit web interface |
| Pipeline | train_pipeline.py | Offline training entry point |

---

## 6. Supported Career Labels
1. Data Scientist
2. Software Engineer
3. Machine Learning Engineer
4. Data Analyst
5. Web Developer
6. Cybersecurity Analyst
7. Business Analyst
8. UX Designer
9. Network Engineer
10. Database Administrator
